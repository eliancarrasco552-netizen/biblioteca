#ifndef FUNCIONES_H_
#define FUNCIONES_H_

#ifndef FUNCIONES_H
#define FUNCIONES_H

void menuLibros();
void menuSocios();
void menuPrestamos();


#endif // FUNCIONES_H

#endif // FUNCIONES_H_
